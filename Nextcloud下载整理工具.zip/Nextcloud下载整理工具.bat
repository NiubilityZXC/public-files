@echo off
setlocal
set "SCRIPT=%~dp0flatten_nextcloud_download.ps1"

if not exist "%SCRIPT%" (
  echo Missing helper script:
  echo %SCRIPT%
  pause
  exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" %*
echo.
echo Finished. You may close this window.
pause
