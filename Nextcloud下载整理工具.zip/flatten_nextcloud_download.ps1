param(
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]] $InputPaths
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Show-Message($text, $icon) {
    [System.Windows.Forms.MessageBox]::Show(
        $text,
        "Nextcloud Download Cleaner",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        $icon
    ) | Out-Null
}

function Select-Source {
    Show-Message "Drag a Nextcloud ZIP or downloaded folder onto the BAT file. You can also choose a ZIP file now. If you want to choose a folder, cancel the ZIP dialog." ([System.Windows.Forms.MessageBoxIcon]::Information)

    $fileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $fileDialog.Title = "Choose a Nextcloud ZIP file"
    $fileDialog.Filter = "ZIP files (*.zip)|*.zip|All files (*.*)|*.*"
    $fileDialog.Multiselect = $false
    if ($fileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $fileDialog.FileName
    }

    $folderDialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $folderDialog.Description = "Choose an extracted Nextcloud folder"
    if ($folderDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        return $folderDialog.SelectedPath
    }

    return $null
}

function Get-SafeName([string] $Name) {
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    $builder = New-Object System.Text.StringBuilder

    foreach ($ch in $Name.ToCharArray()) {
        if ([Array]::IndexOf($invalid, $ch) -ge 0) {
            [void] $builder.Append("_")
        } else {
            [void] $builder.Append($ch)
        }
    }

    $clean = $builder.ToString().Trim()
    while ($clean.EndsWith(".")) {
        $clean = $clean.Substring(0, $clean.Length - 1)
    }
    if ([string]::IsNullOrWhiteSpace($clean)) {
        $clean = "unnamed"
    }

    $maxLength = 180
    if ($clean.Length -gt $maxLength) {
        $extension = [System.IO.Path]::GetExtension($clean)
        $stem = [System.IO.Path]::GetFileNameWithoutExtension($clean)
        $stemMax = [Math]::Max(20, $maxLength - $extension.Length)
        if ($stem.Length -gt $stemMax) {
            $stem = $stem.Substring(0, $stemMax)
        }
        $clean = "$stem$extension"
    }

    return $clean
}

function Get-UniquePath([string] $Path) {
    if (-not (Test-Path -LiteralPath $Path)) {
        return $Path
    }

    $directory = Split-Path -Parent $Path
    $filename = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    $extension = [System.IO.Path]::GetExtension($Path)
    $index = 2

    while ($true) {
        $candidate = Join-Path $directory "$filename ($index)$extension"
        if (-not (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
        $index++
    }
}

function Get-UniqueDirectory([string] $Path) {
    if (-not (Test-Path -LiteralPath $Path)) {
        return $Path
    }

    $parent = Split-Path -Parent $Path
    $name = Split-Path -Leaf $Path
    $index = 2

    while ($true) {
        $candidate = Join-Path $parent "$name ($index)"
        if (-not (Test-Path -LiteralPath $candidate)) {
            return $candidate
        }
        $index++
    }
}

function New-OutputDirectory([string] $Source) {
    $parent = Split-Path -Parent $Source
    $leaf = Split-Path -Leaf $Source
    if ([System.IO.Path]::GetExtension($leaf).ToLowerInvariant() -eq ".zip") {
        $leaf = [System.IO.Path]::GetFileNameWithoutExtension($leaf)
    }

    $safeLeaf = Get-SafeName $leaf
    $output = Join-Path $parent "flattened_$safeLeaf"
    $output = Get-UniqueDirectory $output
    New-Item -ItemType Directory -Path $output -Force | Out-Null
    return $output
}

function Copy-StreamToFile($InputStream, [string] $TargetPath) {
    $outputStream = [System.IO.File]::Create($TargetPath)
    try {
        $InputStream.CopyTo($outputStream)
    } finally {
        $outputStream.Dispose()
    }
}

function Flatten-Zip([string] $ZipPath, [string] $OutputDirectory) {
    $count = 0
    $errors = 0
    $archive = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)

    try {
        foreach ($entry in $archive.Entries) {
            if ([string]::IsNullOrEmpty($entry.Name)) {
                continue
            }

            $safeName = Get-SafeName $entry.Name
            $target = Get-UniquePath (Join-Path $OutputDirectory $safeName)

            try {
                $inputStream = $entry.Open()
                try {
                    Copy-StreamToFile $inputStream $target
                } finally {
                    $inputStream.Dispose()
                }

                try {
                    [System.IO.File]::SetLastWriteTime($target, $entry.LastWriteTime.DateTime)
                } catch {
                    # Timestamps are nice to have, but not worth failing the whole job.
                }

                $count++
                Write-Host "OK: $safeName"
            } catch {
                $errors++
                Write-Host "FAILED: $($entry.FullName)"
                Write-Host $_.Exception.Message
            }
        }
    } finally {
        $archive.Dispose()
    }

    return @{ Count = $count; Errors = $errors }
}

function Flatten-Folder([string] $FolderPath, [string] $OutputDirectory) {
    $count = 0
    $errors = 0
    $files = Get-ChildItem -LiteralPath $FolderPath -File -Recurse -Force

    foreach ($file in $files) {
        $safeName = Get-SafeName $file.Name
        $target = Get-UniquePath (Join-Path $OutputDirectory $safeName)

        try {
            Copy-Item -LiteralPath $file.FullName -Destination $target -Force
            try {
                [System.IO.File]::SetLastWriteTime($target, $file.LastWriteTime)
            } catch {
                # Ignore timestamp failures.
            }
            $count++
            Write-Host "OK: $safeName"
        } catch {
            $errors++
            Write-Host "FAILED: $($file.FullName)"
            Write-Host $_.Exception.Message
        }
    }

    return @{ Count = $count; Errors = $errors }
}

function Process-Source([string] $Source) {
    $resolved = (Resolve-Path -LiteralPath $Source).Path
    $output = New-OutputDirectory $resolved

    Write-Host ""
    Write-Host "Source: $resolved"
    Write-Host "Output: $output"
    Write-Host ""

    if (Test-Path -LiteralPath $resolved -PathType Container) {
        $result = Flatten-Folder $resolved $output
    } elseif ([System.IO.Path]::GetExtension($resolved).ToLowerInvariant() -eq ".zip") {
        $result = Flatten-Zip $resolved $output
    } else {
        throw "Unsupported input. Please use a ZIP file or a folder."
    }

    Write-Host ""
    Write-Host "Done. Files: $($result.Count), errors: $($result.Errors)"
    explorer.exe $output

    if ($result.Errors -gt 0) {
        Show-Message "Finished with errors. Files: $($result.Count), errors: $($result.Errors). The output folder has been opened." ([System.Windows.Forms.MessageBoxIcon]::Warning)
    } else {
        Show-Message "Finished. Files: $($result.Count). The output folder has been opened." ([System.Windows.Forms.MessageBoxIcon]::Information)
    }
}

try {
    if (-not $InputPaths -or $InputPaths.Count -eq 0) {
        $selected = Select-Source
        if (-not $selected) {
            exit 0
        }
        $InputPaths = @($selected)
    }

    foreach ($path in $InputPaths) {
        Process-Source $path
    }
} catch {
    Write-Host ""
    Write-Host "ERROR:"
    Write-Host $_.Exception.Message
    Show-Message $_.Exception.Message ([System.Windows.Forms.MessageBoxIcon]::Error)
    exit 1
}
